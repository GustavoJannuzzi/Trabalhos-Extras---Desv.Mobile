package org.example

fun main() {
    // Testando a função com o código de ação "val3"
    buscarDadosAcaoComJsoup("vale3")
}
